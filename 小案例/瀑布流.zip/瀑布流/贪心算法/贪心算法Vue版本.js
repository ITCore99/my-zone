
let halfInnerWidth = document.body.clientWidth / 2
let vm = new Vue({
  el: '#app',
  data: {
    // 图片资源
    imgs: [],
    // 缩放比计算
    halfInnerWidth,
    // 左侧索引
    leftImgIndexes: [],
    // 右侧索引
    rightImgIndexes: [],
    // 所有图片高度
    imgHeights: []
  },
  created() {
    this.imgs = getSisters(1)
  },
  mounted() {
    this.loadImgHeights(this.imgs).then(res => {
      this.imgHeights = res
      let bothHeightObj = this.greedy(res)
      this.leftImgIndexes = bothHeightObj.left
      this.rightImgIndexes = bothHeightObj.right
    })
  },
  methods: {
    // 加载获取所有图片的高度
    loadImgHeights(imgs) {
      return new Promise((resolve, reject) => {
        const length = imgs.length
        const lengthArr = []
        let count = 0
        // 加载函数
        const load = (index) => {
          let img = new Image()
          const checkIfFinish = () => {
            count++
            if (count === length) {
              resolve(lengthArr)
            }
          }
          img.onload = () => {
            const ratio = img.height / img.width
            // 注意这里的由于图片会填充满一侧所有这里的一般的屏幕的宽度就相当于是图片的宽度 所以在乘以图片高度就是
            // 图片在当前的宽度下的高度
            const halfHeight = ratio * this.halfInnerWidth 
            // 高度按屏幕一半的比例来计算
            lengthArr[index] = halfHeight
            checkIfFinish()
          }
    
          img.onerror = () => {
            lengthArr[index] = 0
            checkIfFinish()
          }
          img.src = imgs[index]
        }
        imgs.forEach((img, index) => load(index));
      })
    },
    // 找到左侧右侧分别展示图片的索引
    greedy(heightArr){
      let leftHeight = 0
      let rightHeight = 0
      let left = []
      let right = []
      heightArr.forEach((height, index) => {
        if (leftHeight >= rightHeight) {
          right.push(index)
          rightHeight += height
        } else {
          left.push(index)
          leftHeight += height
        }
      })
      return {left, right}
    }
  }
})






